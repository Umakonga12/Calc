# Calc
Simple Calculator using python
